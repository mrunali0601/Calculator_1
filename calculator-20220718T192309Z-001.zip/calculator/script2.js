var output = document.getElementById("input");
var input =  document.querySelectorAll("button");
 function allclear(input){
     output = "";

 }